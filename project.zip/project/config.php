<?php

$conn = mysqli_connect('localhost','root','','SHOP') or die('connection failed');

?>